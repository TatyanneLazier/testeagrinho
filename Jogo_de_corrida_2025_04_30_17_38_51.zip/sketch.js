let xJogador1 = 0;
let xJogador2 = 0;
let p;

function setup() {
  createCanvas(400, 400);
  p = createP("regras, clique duas vezes para sumir");
  p.position(5, 10);
}

function doubleClicked() {
  p.remove();
}
function draw() {
  ativaJogo();
  desenhaJogadores();
  desenhaLinhadeChegada();
  quemGanha();
  texto();
}
function texto() {
  textSize(25);
  text("Esse jogo a regra e", 10, 20);
}

function ativaJogo() {
  if (focused == true) {
    background("rgb(111,255,0)");
  } else {
    background("rgb(128,27,0)");
  }
}

function desenhaJogadores() {
  textSize(50);
  text("😇", xJogador1, 100);
  text("🤡", xJogador2, 300);
}

function desenhaLinhadeChegada() {
  fill("white");
  rect(350, 0, 25, 400);
  fill("black");
  for (let yAtual = 0; yAtual < 400; yAtual += 20) {
    rect(350, yAtual, 10, 10);
  }
}

function quemGanha() {
  if (xJogador1 > 350) {
    text("Anjo venceu", 100, 100);
    noLoop(); //faz parar de executar
  }
  if (xJogador2 > 350) {
    text("Graça venceu", 100, 100);
    noLoop();
  }
}

function keyRealeased() {
  if (key == "a") {
    xJogador1 += random(8);
  }
  if (key == "s") {
    xJogador2 += random(8);
    //xJogador1 = xJogador1 + random(8); //random=aleatorio
    //xJogador2 = xJogador2 + random(8);//para simplificar pode ser+=random(8)
  }
}
